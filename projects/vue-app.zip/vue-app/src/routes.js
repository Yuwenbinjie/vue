import Home from './components/home'
import Test from './components/test'
export default[
  {path:"/",component:Home},
  {path:"/test",component:Test}
]
