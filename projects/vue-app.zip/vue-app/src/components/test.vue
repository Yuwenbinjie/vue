<!-- template:是我们需要的模版，有且只有一个根标签 -->
<template>
  <div id="test">
    <h1>Hello test!</h1>
  </div>
</template>

<script>
  export default {
    name: 'test',
    data() {
      return {
      }
    },
    methods: {
    }
  }

</script>

<style scoped>

</style>
